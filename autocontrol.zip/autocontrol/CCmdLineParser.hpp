/*
 * SPDX-FileCopyrightText: Copyright (c) 2018-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

/* STL Headers */
#include <unistd.h>
#include <sys/stat.h>
#include <cstring>
#include <iostream>
#include <getopt.h>
#include <vector>
#include <iomanip>

#include "NvSIPLTrace.hpp" // NvSIPLTrace to set library trace level
#include "NvSIPLQuery.hpp" // NvSIPLQuery to display platform config

#ifndef CCMDPARSER_HPP
#define CCMDPARSER_HPP

using namespace std;
using namespace nvsipl;

class CCmdLineParser
{
 public:
    // Command line options
    string sConfigName = "";
    vector<uint32_t> vMasks;
    vector<uint16_t> vBufCounts;
    string sTestConfigFile = "";
    int32_t uRunDurationSec = -1;
    uint32_t verbosity = 1u;
    bool bDisableRaw = true;
    bool bDisableISP0 = false;
    bool bDisableISP1 = false;
    bool bDisableISP2 = false;
    bool bShowIspSettingsOverride = false;  // Enable to ISP settings override feature.
    bool bShowFPS = false;
    bool bShowMetadata = false;
    PluginType autoPlugin = NV_PLUGIN;
    bool bAutoRecovery = false;
#if !NV_IS_SAFETY
    bool bNvSci = false;
#endif // !NV_IS_SAFETY
    bool bEnableProfiling = false;
    string sNitoFolderPath = "";
    vector<sring> vNitoFiles;
    bool bShowEEPROM = false;
    bool bIgnoreError = false;
    bool bEnableSc7Boot = false;
    bool bIspInputCropEnable = false;
    uint32_t uIspInputCropY = 0u;
    uint32_t uIspInputCropH = 0u;
    bool bEnableStatsOverrideTest = false;
    bool bIsParkingStream = false;
    bool bIsRGBIRsensor = false;
    bool bIsCrossTrafficIX = false;
    bool bDisableSubframe = false;
    string sProfilePrefix = "";
    bool bEnablePassive = false;
    string sFiledumpPrefix = "";
    uint32_t uNumSkipFrames = 0u;
    uint64_t uNumWriteFrames = -1u;
    bool bGpioIdxDes = false;
    /* GPIO2 is the default GPIO to receive the FRSYNC signal */
    uint32_t uGpioIdxDes[MAX_DEVICEBLOCKS_PER_PLATFORM][MAX_CAMERAMODULES_PER_BLOCK] =
        {{2U, 2U, 2U, 2U},
        {2U, 2U, 2U, 2U},
        {2U, 2U, 2U, 2U},
        {2U, 2U, 2U, 2U}};
    uint32_t uFsyncMuxDes[3] = {0U, 0U, 0U};
    bool bDisableAuth = false;
    uint64_t uCamRecCfg = 0u;
#if !NV_IS_SAFETY
    bool bWriteEEPROM = false;
    uint32_t uExpNo = -1;
    uint32_t uNumDisplays = 0u;
    NvSiplRect oDispRect = {0, 0, 0, 0};
    bool bAutoLEDControl = false;
    // Non-safety only option to fetch and display NITO Metadata (UUID, dataHash, schemaHash) to
    // console. Let user indicate number of parameter sets present in NITO file, default to 10.
    bool bShowNitoMetadata = false;
    bool bSetNitoMetadataNumParamSets = false;
    uint64_t uShowNitoMetadataNumParamSets = 10u;
#endif // !NV_IS_SAFETY

#if !(NV_IS_SAFETY) || (SAFETY_DBG_OV)
    bool bTwoPassIsp = false;
    bool bTwoPassLowToHigh = true;
    vector<string> vInputRawFiles;
#endif // !(NV_IS_SAFETY) || (SAFETY_DBG_OV)

    bool bFsyncProgramStartTime = false;
    bool bFsyncMuxDes = false;
    uint8_t uFsyncGroupId = 0u;
    uint64_t uStartTimeTSCTicks = 0u;
    bool bFsyncProgramGroupNow = false;
    bool bFsyncGetTscTicks = false;

    bool bDynamicI2C = false;

    // Other members
    bool bRectSet = false;

    static void ShowConfigs(string sConfigFile="")
    {
        auto pQuery = INvSIPLQuery::GetInstance();
        if (pQuery == nullptr) {
            cout << "INvSIPLQuery::GetInstance() failed\n";
        }

        auto status = pQuery->ParseDatabase();
        if (status != NVSIPL_STATUS_OK) {
            LOG_ERR("INvSIPLQuery::ParseDatabase failed\n");
        }

        if (sConfigFile != "") {
            status = pQuery->ParseJsonFile(sConfigFile);
            if (status != NVSIPL_STATUS_OK) {
                LOG_ERR("Failed to parse test config file\n");
            }
            LOG_INFO("Available platform configurations\n");
        }
        for (auto &cfg : pQuery->GetPlatformCfgList()) {
            cout << "\t" << std::setw(35) << std::left << cfg->platformConfig << ":" << cfg->description << endl;
        }
    }

    static void ShowUsage(void)
    {
#if !NV_IS_SAFETY
        int32_t numDisplays = 1;
        // TODO Support number output displays query
#endif // !NV_IS_SAFETY

        cout << "Usage:\n";
        cout << "-h or --help                               :Prints this help\n";
        cout << "-c or --platform-config 'name'             :Platform configuration. Supported values\n";
        ShowConfigs();
        cout << "-m or --link-enable-masks 'masks'          :Enable masks for links on each deserializer connected to CSI\n";
        cout << "                                           :masks is a list of masks for each deserializer.\n";
        cout << "                                           :Eg: '0x0000 0x1101 0x0000 0x0000' disables all but links 0, 2 and 3 on CSI-CD intrface\n";
        cout << "-r or --runfor <seconds>                   :Exit application after n seconds (also disables runtime menu)\n";
        cout << "-v or --verbosity <level>                  :Set verbosity\n";
#if !NV_IS_SAFETY
        cout << "                                           :Supported values (default: 1)\n";
        cout << "                                           : " << INvSIPLTrace::LevelNone << " (None)\n";
        cout << "                                           : " << INvSIPLTrace::LevelError << " (Errors)\n";
        cout << "                                           : " << INvSIPLTrace::LevelWarning << " (Warnings and above)\n";
        cout << "                                           : " << INvSIPLTrace::LevelInfo << " (Infos and above)\n";
        cout << "                                           : " << INvSIPLTrace::LevelDebug << " (Debug and above)\n";
#endif // !NV_IS_SAFETY
        cout << "-t or --test-config-file <file>            :Set custom platform config json file\n";
        cout << "-l or --list-configs                       :List configs from file specified via -t or --test-config-file\n";
        cout << "-R or --enableRawOutput                    :Enable the Raw output\n";
        cout << "-0 or --disableISP0Output                  :Disable the ISP0 output\n";
        cout << "-1 or --disableISP1Output                  :Disable the ISP1 output\n";
        cout << "-2 or --disableISP2Output                  :Disable the ISP2 output\n";
        cout << "-4 or --pluginIspOverride                  :Show ISP settings override example using CUSTOM_PLUGIN0\n";
        cout << "-s or --showfps                            :Show FPS (frames per second) every 2 seconds\n";
        cout << "-M or --showmetadata                       :Show Metadata when RAW output is enabled\n";
        cout << "-p or --plugin <type>                      :Auto Control Plugin. Supported types (default: If nito available 0 else 1)\n";
        cout << "                                           : " << NV_PLUGIN << " Nvidia AE/AWB Plugin\n";
        cout << "                                           : " << CUSTOM_PLUGIN0 << " Custom Plugin\n";
        cout << "-a or --autorecovery                       :Recover deserializer link failure automatically\n";
#if !NV_IS_SAFETY
        cout << "-C or --nvsci                              :Use NvSci for communication and synchronization\n";
#endif // !NV_IS_SAFETY
        cout << "-k or --profile <file-prefix>              :Dump profiling timestamps in file-prefix_cam_x_out_y.csv file\n";
        cout << "-N or --nito <folder>                      :Path to folder containing NITO files\n";
        cout << "-n or --nitofile <filename>                :Name of a NITO file.  This option can be specified multiple times.\n";
        cout << "-O or --icrop 'y+h'                        :Specifies the cropping at the input in the format 'y+h'\n";
        cout << "-e or --showEEPROM                         :Show EEPROM data\n";
        cout << "-I or --ignoreError                        :Ignore the fatal error\n";
        cout << "-o or --enableStatsOverrideTest            :Enable ISP statistics settings override\n";
        cout << "-u or --disableSubframe                    :Disable Subframe feature\n";
        cout << "-S or --enablePassive                      :Enable passive mode\n";
        cout << "-f or --filedump-prefix 'str'              :Dump RAW file with filename prefix 'str'  when RAW output is enabled.\n";
        cout << "-K or --skipFrames <val>                   :Number of frames to skip before writing to file\n";
        cout << "-W or --writeFrames <val>                  :Number of frames to write to file\n";
        cout << "-Z or --disableAuth                        :Forcefully disable authentication for all camera sensors.\n";
        cout << "-w or --camRecCfg <val>                    :Recorder configuration\n";
        cout << "                                           :0 - No recorder support(default)\n";
        cout << "                                           :1 - Recorder support with the cable version 1\n";
        cout << "                                           :2 - Recorder support with the cable version 2\n";
#if !NV_IS_SAFETY
        cout << "-T or --twoPassISP <val>                   :Process the same captured frames through two different ISP pipelines\n";
        cout << "                                           :Set value to zero to send frames from pipeline with higher ID to pipeline with lower ID\n";
        cout << "                                           :Use any nonzero value to send frames from pipeline with lower ID to pipeline with higher ID\n";
        cout << "                                           :Use comma separator for multiple files.\n";
        cout << "-z or --writeEEPROM                        :Write EEPROM data\n";
        cout << "-E or --setSensorCharMode <expNo>          :Set sensor in characterization mode with exposure number.\n";
        cout << "-d or --num-disp <num>                     :Number of displays\n";
        cout << "                                           :Number of available displays: " << numDisplays << endl;
        cout << "-p or --disp-win-pos 'rect'                :Display position, where rect is x0, y0, width, height\n";
        cout << "-A or --autoLED                            :Enable automatic LED control, specifically for AR0234\n";
        cout << "-G or --showNitoMetadata                   :Get and display NITO Metadata (ID, dataHash, schemaHash) from NITO file(s) to console.\n";
        cout << "-g or --numParameterSetsInNITO <val>       :Number of parameter sets in NITO file. Defaults to 10, must be >=1. Use if expecting >10 parameter sets in NITO file(s).\n";
#endif // !NV_IS_SAFETY
#if !(NV_IS_SAFETY) || (SAFETY_DBG_OV)
        cout << "-i or --input-raw-files <file1[,file2]...> :Set input RAW files for simulator mode testing.\n";
#endif // !(NV_IS_SAFETY) || (SAFETY_DBG_OV)
        cout << "-D or --syncGPIOIdxDes 'gpios'             :GPIO index of the deserializer for FRSYNC signal. Applicable only for the specific board\n";
        cout << "                                           :GPIO index is a list of GPIOs for each deserializer.\n";
        cout << "                                           :Eg: '2 2 2 2 2 2 2 2 2 2 2 2 2 4 2 4' use GPIO 4 for the link 1 and 3 on CSI-GH interface and GPIO 2 is used for other links\n";
        cout << "-U or --syncMuxSelDes 'Indexes'            :Selection index to the multiplexer. Applicable only for the specific board\n";
        cout << "                                           :Index is a list of selection index for each deserializer.\n";
        cout << "                                           :Eg: '1 2 3' selects the selection index 1 for the multiplxer on CSI-CD, the selection index 2 for the multiplxer on CSI-EF, the selection index 3 for the multiplxer on CSI-GH,\n";
        cout << "-F or --fsyncGroupStartTime 'group ticks'  :Group ID and start time in tsc ticks to be programmed.\n";
        cout << "                                           :All fsync signal generator in group will start at specified start time.\n";
        cout << "                                           :Eg: 'group_id start_time_in_tsc_ticks'.\n";
        cout << "-x or --getTimeTSC                         :Get the current TSC ticks value.\n";
        cout << "-b or --fsyncGroupStartNow group           :Start the fsync group now.\n";
        cout << "                                           :All fsync signal generator in group will start at current time.\n";
        cout << "-B or --bufferAlloc 'Buffers'              :Set number of buffers to allocate and register for each channel (default: 6 buffers for capture, 4 for each ISP channel)\n";
        cout << "                                           :Eg: '40 64 64 64' selects 40 buffers for the capture (VI) channel and 64 for ISP0/1/2\n";
        cout << "-y or --dynamic_i2c                        :Set dynamic i2c mode.\n";

        return;
    }

    int Parse(int argc, char* argv[])
    {
        const char *const short_options = "hc:m:nr:v:t:lR0124sMP:aCk:N:n:O:eIo:Sf:K:W:ZF:w:7:xb:B:"
#if !NV_IS_SAFETY
                                          "E:d:p:AGg:z:i:T:D:Uy"
#elif (SAFETY_DBG_OV)
                                          "i:"
#endif // !NV_IS_SAFETY
                                          ;
        const struct option long_options[] =
        {
            { "help",                     no_argument,       0, 'h' },
            { "platform-config",          required_argument, 0, 'c' },
            { "link-enable-masks",        required_argument, 0, 'm' },
            { "enable-notification",      no_argument,       0, 'n' },
            { "runfor",                   required_argument, 0, 'r' },
            { "verbosity",                required_argument, 0, 'v' },
            { "test-config-file",         required_argument, 0, 't' },
            { "list-configs",             no_argument,       0, 'l' },
            { "enableRawOutput",          no_argument,       0, 'R' },
            { "disableISP0Output",        no_argument,       0, '0' },
            { "disableISP1Output",        no_argument,       0, '1' },
            { "disableISP2Output",        no_argument,       0, '2' },
            { "pluginIspOverride",        no_argument,       0, '4' },
            { "showfps",                  no_argument,       0, 's' },
            { "showmetadata",             no_argument,       0, 'M' },
            { "plugin",                   required_argument, 0, 'P' },
            { "autorecovery",             no_argument,       0, 'a' },
#if !NV_IS_SAFETY
            { "nvsci",                    no_argument,       0, 'C' },
#endif // !NV_IS_SAFETY
            { "profile",                  required_argument, 0, 'k' },
            { "nito",                     required_argument, 0, 'N' },
            { "nitofile",                 required_argument, 0, 'n' },
            { "icrop",                    required_argument, 0, 'O' },
            { "showEEPROM",               no_argument,       0, 'e' },
            { "ignoreError",              no_argument,       0, 'I' },
            { "enableStatsOverrideTest",  no_argument,       0, 'o' },
            { "disableSubframe",           no_argument,      0, 'u' },
            { "enablePassive",            no_argument,       0, 'S' },
            { "filedump-prefix",          required_argument, 0, 'f' },
            { "skipFrames",               required_argument, 0, 'K' },
            { "writeFrames",              required_argument, 0, 'W' },
#if !(NV_IS_SAFETY) || (SAFETY_DBG_OV)
            { "input-raw-files",          required_argument, 0, 'i' },
#endif // !(NV_IS_SAFETY) || (SAFETY_DBG_OV)
#if !NV_IS_SAFETY
            { "twoPassISP",               required_argument, 0, 'T' },
#endif // !NV_IS_SAFETY
            { "syncMuxSelDes",            required_argument, 0, 'U' },
            { "syncGPIOIdxDes",           required_argument, 0, 'D' },
            { "disableAuth",              no_argument,       0, 'Z' },
            { "camRecCfg",                required_argument, 0, 'w' },
            { "sc7-boot",                 no_argument,       0, '7' },
#if !NV_IS_SAFETY
            { "writeEEPROM",              no_argument,       0, 'z' },
            { "setSensorCharMode",        required_argument, 0, 'E' },
            { "num-disp",                 required_argument, 0, 'd' },
            { "disp-win-pos",             required_argument, 0, 'p' },
            { "autoLED",                  no_argument,       0, 'A' },
            { "showNitoMetadata",         no_argument,       0, 'G' },
            { "numParameterSetsInNITO",   required_argument, 0, 'g' },
#endif // !NV_IS_SAFETY
            { "fsyncGroupStartTime",      required_argument, 0, 'F' },
            { "getTimeTSC",               no_argument,       0, 'x' },
            { "fsyncGroupStartNow",       required_argument, 0, 'b' },
            { "bufferAlloc",              required_argument, 0, 'B' },
            { "dynamic_i2c",              no_argument,       0, 'y' },
            { 0,                          0,                 0,  0 }
        };

        int index = 0;
        auto bShowHelp = false;
        auto bShowConfigs = false;

        while (1) {
            const auto getopt_ret = getopt_long(argc, argv, short_options , &long_options[0], &index);
            if (getopt_ret == -1) {
                // Done parsing all arguments.
                break;
            }

            switch (getopt_ret) {
            default: /* Unrecognized option */
            case '?': /* Unrecognized option */
                cout << "Invalid or Unrecognized command line option. Specify -h or --help for options\n";
                bShowHelp = true;
                break;
            case 'h': /* -h or --help */
                bShowHelp = true;
                break;
            case 'c':
                sConfigName = string(optarg);
                break;
            case 'm':
            {
                char* token = std::strtok(optarg, " ");
                while(token != NULL) {
                    vMasks.push_back(stoi(token, nullptr, 16));
                    token = std::strtok(NULL, " ");
                }
            }
                break;
            case 'r':
                uRunDurationSec = atoi(optarg);
                break;
            case 'v':
                verbosity = atoi(optarg);
                break;
            case 't':
                sTestConfigFile = string(optarg);
                break;
            case 'l':
                bShowConfigs = true;
                break;
            case 'R':
                bDisableRaw = false;
                break;
            case '0':
                bDisableISP0 = true;
                break;
            case '1':
                bDisableISP1 = true;
                break;
            case '2':
                bDisableISP2 = true;
                break;
            case '4':
                bShowIspSettingsOverride = true;
            case 's':
                bShowFPS = true;
                break;
            case 'M':
                bShowMetadata = true;
                break;
            case 'P':
                autoPlugin = (PluginType) atoi(optarg);
                break;
            case 'a':
                bAutoRecovery = true;
                break;
#if !NV_IS_SAFETY
            case 'C':
                bNvSci = true;
                break;
#endif // !NV_IS_SAFETY
            case 'k':
                bEnableProfiling = true;
                if (optarg[0] == '-') {
                    cout << "Invalid file prefix for profiling.\n";
                    bShowHelp = true;
                    break;
                }
                sProfilePrefix = string(optarg);
                break;
            case 'N':
                sNitoFolderPath = string(optarg);
                break;
            case 'n':
                vNitoFiles.push_back(string(optarg));
                break;
            case 'O':
                sscanf(optarg, "%d+%d", &uIspInputCropY, &uIspInputCropH);
                bIspInputCropEnable = true;
                break;
            case 'e':
                bShowEEPROM = true;
                break;
            case 'I':
                bIgnoreError = true;
                break;
            case '7':
                bEnableSc7Boot = true;
                break;
            case 'o':
                bEnableStatsOverrideTest = true;
                break;
            case 'u':
                bDisableSubframe = true;
                break;
            case 'S':
                bEnablePassive = true;
                break;
            case 'f':
                sFiledumpPrefix = string(optarg);
                break;
            case 'K':
                uNumSkipFrames = atoi(optarg);
                break;
            case 'W':
                uNumWriteFrames = atoi(optarg);
                break;
            case 'Z':
                bDisableAuth = true;
                break;
            case 'w':
                uCamRecCfg = atoi(optarg);
                break;
#if !(NV_IS_SAFETY) || (SAFETY_DBG_OV)
            case 'i':
                char *rawFile;
                rawFile = strtok(optarg, ",");
                while (rawFile != NULL) {
                    vInputRawFiles.push_back(string(rawFile));
                    rawFile = strtok (NULL, ",");
                }
                break;
#endif // !(NV_IS_SAFETY) || (SAFETY_DBG_OV)
#if !NV_IS_SAFETY
            case 'T':
                bTwoPassIsp = true;
                bTwoPassLowToHigh = (atoi(optarg) != 0);
                break;
            case 'z':
                bWriteEEPROM = true;
                break;
            case 'E':
                uExpNo = atoi(optarg);
                break;
            case 'd':
                uNumDisplays = atoi(optarg);
                if (uNumDisplays == 0u) {
                    cout << "Warning: number of displays cannot be zero, setting to one" << endl;
                    uNumDisplays = 1u;
                }
                break;
            case 'p':
                int32_t x, y, w, h;
                sscanf(optarg, "%d %d %d %d", &x, &y, &w, &h);
                oDispRect.x0 = x;
                oDispRect.y0 = y;
                oDispRect.x1 = oDispRect.x0 + w;
                oDispRect.y1 = oDispRect.y0 + h;
                bRectSet = true;
                break;
            case 'A':
                bAutoLEDControl = true;
                break;
            case 'G':
                bShowNitoMetadata = true;
                break;
            case 'g':
                bSetNitoMetadataNumParamSets = true;
                uShowNitoMetadataNumParamSets = atoi(optarg);
                break;
#endif // !NV_IS_SAFETY
            case 'D':
                int32_t gpio[MAX_CAMERAMODULES_PER_BLOCK * MAX_DEVICEBLOCKS_PER_PLATFORM];
                sscanf(optarg, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",
                                              &gpio[0], &gpio[1], &gpio[2], &gpio[3],
                                              &gpio[4], &gpio[5], &gpio[6], &gpio[7],
                                              &gpio[8], &gpio[9], &gpio[10], &gpio[11],
                                              &gpio[12], &gpio[13], &gpio[14], &gpio[15]);

                for (uint8_t i = 0U; i < MAX_CAMERAMODULES_PER_BLOCK * MAX_DEVICEBLOCKS_PER_PLATFORM; i++) {
                    uGpioIdxDes[i / 4U][i % 4U] = gpio[i];
                }
                bGpioIdxDes = true;
                break;
            case 'U':
                int32_t fsyncMux[3];
                sscanf(optarg, "%d %d %d", &fsyncMux[0], &fsyncMux[1], &fsyncMux[2]);
                uFsyncMuxDes[0] = fsyncMux[0];
                uFsyncMuxDes[1] = fsyncMux[1];
                uFsyncMuxDes[2] = fsyncMux[2];

                bFsyncMuxDes = true;
                break;
            case 'F':
                bFsyncProgramStartTime = true;
                sscanf(optarg, "%hhu %lu", &uFsyncGroupId, &uStartTimeTSCTicks);
                break;
            case 'x':
                bFsyncGetTscTicks = true;
                break;
            case 'b':
                bFsyncProgramGroupNow = true;
                uFsyncGroupId = atoi(optarg);
                break;
            case 'y':
                bDynamicI2C = true;
                break;
            case 'B':
                char* token = std::strtok(optarg, " ");
                while(token != NULL) {
                    vBufCounts.push_back(stoi(token, nullptr));
                    token = std::strtok(NULL, " ");
                }
                if (vBufCounts.size() != 4) {
                    cout << "Must configure all four buffer counts even if not in use (ICP, ISP0, ISP1, ISP2)\n";
                    return -1;
                }
                break;
            }
        }

        if (bShowHelp) {
            ShowUsage();
            return -1;
        }

        if (bShowConfigs) {
            // User just wants to list available configs
            ShowConfigs(sTestConfigFile);
            return -1;
        }

        // Check for bad arguments
        if (sConfigName == "") {
            cout << "No platform configuration specified.\n";
            return -1;
        }

        if (bDisableRaw &&
            bDisableISP0 &&
            bDisableISP2 &&
            bDisableISP1) {
            cout << "At-least one output must be enabled\n";
            return -1;
        }

        if ((sFiledumpPrefix == "") && (uNumSkipFrames != 0u)) {
            cout << "skipFrames is only applicable when file dump is enabled\n";
            return -1;
        }

        if ((sFiledumpPrefix == "") && (uNumWriteFrames != -1u)) {
            cout << "writeFrames is only applicable when file dump is enabled\n";
            return -1;
        }

        if ((strstr(sConfigName.c_str(), "OV2312")) ||
            (strstr(sConfigName.c_str(), "OX05B1"))  ||
            (strstr(sConfigName.c_str(), "O05B1S1DHU"))) {
            if (!bDisableISP2) {
                cout << "ISP2 output is not supported for RGB-IR sensors such as OV2312 and OX05B1\n";
                return -1;
            }
            bIsRGBIRsensor = true;
        }

        if ((strstr(sConfigName.c_str(), "_CROSS_TRAFFIC_IX_CAMERAS")) &&
            (strstr(sConfigName.c_str(), "HYP8_1_CONTI_"))) {
            printf("Cross Traffic + IX configuration detected\n");
            bIsCrossTrafficIX = true;
        }

        string park_substr = "PARKING_STREAM";
        if (strstr(sConfigName.c_str(), park_substr.c_str())) {
            bIsParkingStream = true;
        }

#if !(NV_IS_SAFETY) || (SAFETY_DBG_OV)
        if (bTwoPassIsp) {
            if (bDisableRaw) {
                cout << "Cannot perform two-pass ISP processing without capture output\n";
                return -1;
            }
            if (bDisableISP0 && bDisableISP1 && bDisableISP2) {
                cout << "Cannot perform two-pass ISP processing without any ISP outputs\n";
                return -1;
            }
            if (
#if !NV_IS_SAFETY
                bNvSci ||
#endif // !NV_IS_SAFETY
                (!vInputRawFiles.empty())
#if !NV_IS_SAFETY
                || (uNumDisplays != 0U)
#endif // !NV_IS_SAFETY
                ) {
                cout << "Cannot perform two-pass ISP processing with the given consumer feature\n";
                return -1;
            }
        }
#endif // !(NV_IS_SAFETY) || (SAFETY_DBG_OV)

#if NVMEDIA_QNX
    struct stat buf;
    string ports[]={"0","2","3","6","7"}, prefix = "/dev/cba";

    for(index = 0; index < (int)(sizeof(ports)/sizeof(ports[0])); index++) {
        if(stat((prefix+ports[index]).c_str(),&buf)==0) {
            /*
             * Some CBA deaemons are running,
             * check if the selected camera profile is also CBA
             */
            string cba_substr = "CBA";
            if (!strstr(sConfigName.c_str(), cba_substr.c_str())) {
                /* Issue a friendly reminder */
                cout << "Running non-cba profile on a cba enabled platform: side effects possible\n";
            }
            /* No need to check any further */
            break;
        }
    }
#endif

#if !NV_IS_SAFETY
        if (bIsRGBIRsensor) {
            if ((uNumDisplays > 0u) && !bDisableISP1) {
                cout << "Displaying ISP1 output is not supported for RGB-IR sensors\n";
                return -1;
            }
        }

        if (bAutoLEDControl) {
            string config_substr = "AR0234";
            if (!strstr(sConfigName.c_str(), config_substr.c_str())) {
                cout << "LED control is only supported for AR0234 camera modules\n";
                return -1;
            }
        }

        if (bIsParkingStream) {
            // Display is not supported for platform configuration PARKING_STREAM
            if (uNumDisplays > 0u) {
                cout << "Display is not supported for the given platform configuration\n";
                return -1;
            }
            bIsParkingStream = true;
        }

        string ov2312_substr = "OV2312";
        string ox05b1_substr = "05B1";
        if ((strstr(sConfigName.c_str(), ov2312_substr.c_str())) ||
            (strstr(sConfigName.c_str(), ox05b1_substr.c_str()))) {
            if (!bDisableISP2) {
                cout << "ISP2 output is not supported for RGB-IR sensors such as OV2312 and OX05B1\n";
                return -1;
            }
            if ((uNumDisplays > 0u) && !bDisableISP1) {
                cout << "Displaying ISP1 output is not supported for RGB-IR sensors such as OV2312\n";
                return -1;
            }
            bIsRGBIRsensor = true;
        }

        if ((uNumDisplays > 0u) && !bDisableRaw) {
            // Throw warning if RAW output is being displayed
            cout << "WARNING: RAW output is being requested with Display\n";
            cout << "WARNING: Frame Drops and drops in FPS are likely to be observed\n";
        }

        // User must enable at least one ISP output to use NitoMetadata option
        if (bDisableISP0 &&
            bDisableISP1 &&
            bDisableISP2 &&
            bShowNitoMetadata) {
            cout << "showNitoMetadata only applicable when at least 1 ISP output is enabled\n";
            return -1;
        }

        // SC7 Mode restrictions
        if (bEnableSc7Boot) {
            if (bNvSci) {
                cout << "NvSci Mode not supported in SC7\n";
                return -1;
            }
            if (bTwoPassIsp) {
                cout << "Two Pass ISP Mode not supported in SC7\n";
                return -1;
            }
            if ((uNumDisplays > 0u)) {
                cout << "Display Mode not supported in SC7\n";
                return -1;
            }
        }
        // User must enable showNitoMetadata to specify numParameterSetsInNITO
        if (!bShowNitoMetadata && bSetNitoMetadataNumParamSets) {
            cout << "--numParameterSetsInNITO only applicable when --showNitoMetadata is enabled\n";
            return -1;
        }

        if (bShowNitoMetadata && bSetNitoMetadataNumParamSets) {
            if (uShowNitoMetadataNumParamSets < 1u) {
                cout << "--numParameterSetsInNITO must be >=1 \n";
                return -1;
            }
        }

        if (uExpNo != -1u) {
            // SetSensorCharMode to be used only for Custom Plugin
            if (autoPlugin == CUSTOM_PLUGIN0) {
                string config_substr = "F008A";
                /* SetSensorCharMode is not supported for platform configurations that do not match
                 * sub-string F008A which corresponds to AR0820 sensors supported
                 */
                if (!strstr(sConfigName.c_str(), config_substr.c_str())) {
                    cout << "SetSensorCharMode is not supported for the given platform configuration\n";
                    return -1;
                }
            } else {
                cout << "SetSensorCharMode is not supported for requested Plugin\n";
                return -1;
            }
        }
#endif // !NV_IS_SAFETY

        if (bFsyncProgramStartTime && bFsyncProgramGroupNow) {
            cout << "Cannot provide both --fsyncGroupStartTime and --fsyncGroupStartNow\n";
            return -1;
        }

        if (autoPlugin == NV_PLUGIN && bShowIspSettingsOverride) {
            cout << "ISP settings override NOT supported for NV_PLUGIN \n";
            return -1;
        }
        return 0;
    }

    void PrintArgs() const
    {
        if (sConfigName != "") {
            cout << "Platform configuration name: " << sConfigName << endl;
        }
        if (sTestConfigFile != "") {
            cout << "Platform configuration file: " << sTestConfigFile << endl;
        }
        if (uRunDurationSec != -1) {
            cout << "Running for " << uRunDurationSec << " seconds\n";
        }
        cout << "Verbosity level: " << verbosity << endl;
        if (bDisableRaw) {
            cout << "Raw output: disabled" << endl;
        } else {
            cout << "Raw output: enabled" << endl;
        }
        if (bDisableISP0) {
            cout << "ISP0 output: disabled" << endl;
        } else {
            cout << "ISP0 output: enabled" << endl;
        }
        if (bDisableISP1) {
            cout << "ISP1 output: disabled" << endl;
        } else {
            cout << "ISP1 output: enabled" << endl;
        }
        if (bDisableISP2) {
            cout << "ISP2 output: disabled" << endl;
        } else {
            cout << "ISP2 output: enabled" << endl;
        }
        if (bShowIspSettingsOverride) {
            cout << "ISP settings override: enable" << endl;
        } else {
            cout << "ISP settings override: disable" << endl;
        }
        if (bShowFPS) {
            cout << "Enabled FPS logging" << endl;
        } else {
            cout << "Disabled FPS logging" << endl;
        }
        if (bShowMetadata) {
            cout << "Enabled Metadata logging" << endl;
        } else {
            cout << "Disabled Metadata logging" << endl;
        }
        if (bAutoRecovery) {
            cout << "Enabled automatic recovery" << endl;
        } else {
            cout << "Disabled automatic recovery" << endl;
        }
#if !NV_IS_SAFETY
        if (bNvSci) {
            cout << "Enabled NvSci" << endl;
        } else {
            cout << "Disabled NvSci" << endl;
        }
#endif // !NV_IS_SAFETY
        if (bEnableProfiling) {
            cout << "Enabled profiling" << endl;
        } else {
            cout << "Disabled profiling" << endl;
        }
        if (sNitoFolderPath != "") {
            cout << "NITO folder path: " << sNitoFolderPath << endl;
        }
        if (!vNitoFiles.empty()) {
            cout << "NITO filenames:"
            for (auto str : vNitoFiles) {
                cout << " " << e;
            }
            cout << endl;
        }
        if (bEnableStatsOverrideTest){
            cout << "Enabled ISP Statistics settings override" << endl;
        } else {
            cout << "Disabled ISP Statistics settings override" << endl;
        }
        if (bDisableSubframe) {
            cout << "Subframe : enabled" << endl;
        } else {
            cout << "Subframe : disabled" << endl;
        }
        if (bEnablePassive) {
            cout << "Enabled Passive mode" << endl;
        } else {
            cout << "Disabled Passive mode" << endl;
        }
        if (sFiledumpPrefix != "") {
            cout << "File dump prefix:            " << sFiledumpPrefix << endl;
        }
        if (uNumSkipFrames != 0u) {
            cout << "Number of frames to skip: " << uNumSkipFrames << endl;
        }
        if (uNumWriteFrames != -1u) {
            cout << "Number of frames to write: " << uNumWriteFrames << endl;
        }
        if (bDisableAuth) {
            cout << "Authentication: disabled by the user" << endl;
        }

#if !(NV_IS_SAFETY) || (SAFETY_DBG_OV)
        if (!vInputRawFiles.empty()) {
            cout << "Input raw file(s):           ";
            for (auto s : vInputRawFiles) {
                cout << s << " ";
            }
            cout << endl;
        }
#endif // !(NV_IS_SAFETY) || (SAFETY_DBG_OV)

#if !NV_IS_SAFETY
        if (uNumDisplays > 0u) {
            cout << "Number of displays:          " << uNumDisplays << endl;
            if (bRectSet) {
                uint32_t x = oDispRect.x0, y = oDispRect.y0;
                uint32_t w = oDispRect.x1 - x, h = oDispRect.y1 - y;
                cout << "Display window position:     " << x << " " << y << " " << w << " " << h << endl;
            }
        }
        if (bShowNitoMetadata) {
            cout << "Enabled retrieving/displaying NITO Metadata" << endl;
            if (bSetNitoMetadataNumParamSets) {
                cout << "User specified that all NITO files will have maximum of " << uShowNitoMetadataNumParamSets << " parameter sets\n" << endl;
            }
            else {
                cout << "Expecting all NITO files to have default maximum of " << uShowNitoMetadataNumParamSets << " parameter sets\n" << endl;
            }
        } else {
            cout << "Disabled retrieving/displaying NITO Metadata" << endl;
        }
#endif // !NV_IS_SAFETY
    }
};

#endif //CCMDPARSER_HPP
